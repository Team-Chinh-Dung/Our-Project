<?php
$config = array();
$config['appId'] = 'API KEY';
$config['secret'] = 'SECRET KEY';

$siteConfig = array();
$siteConfig['sitePath'] = 'http://localhost:85/phppot_samples/facebook_open_authentication/';
?>