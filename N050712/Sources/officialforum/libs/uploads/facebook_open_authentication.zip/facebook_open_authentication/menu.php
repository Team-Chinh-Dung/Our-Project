<html>
<head>
<title>Facebook Open Authentication</title>
<style>
body {
font-family: Arial;
}
.menubar {
background-color: #60CC93;
border: #000000 1px solid;
height:22px;
padding: 10px;
width:500px;
}
.menubar a{
font-size: 15px;
}

label {
font-size: 30px;
color: #FFFFFF;
margin-right:300px;
}
.btnlogin {
float:right;
}
<!--Mohan 9962464488-->
</style>
</head>
<body>
<?php
	session_start();
	require_once("facebook.php");
	require_once("config.php");
	$facebook = new Facebook($config);
	
	$loginURL = $facebook->getLoginUrl(array('redirect_uri' => $siteConfig['sitePath'] . 'menu.php?action=login'));
	$logoutURL = $facebook->getLogoutUrl(array('next' => $siteConfig['sitePath'] . 'menu.php?action=logout'));
	
	if(isset($_GET["action"]) && $_GET["action"] == "logout") {
		unset($_SESSION["fb_".$config["appId"]."_access_token"]);
	}
?>
<div class="menubar">
<?php	
	if(isset($_SESSION["fb_".$config["appId"]."_access_token"])) {
?>
<label>Main Menu </label><a href="<?php echo $logoutURL; ?>" title="Facebook Login">Logout</a>
<?php
} else {
?>
<div class="btnlogin">
<a href="<?php echo $loginURL; ?>" title="Facebook Login"><img src="loginwithfacebook.png" alt="Facebook Login"></a>
</div>
<?php
}
?>
</div>
</body>